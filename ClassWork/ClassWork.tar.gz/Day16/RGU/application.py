#!/usr/bin/python
from report import *
"""
Show List of reports:
AddReport method
DisplayReport method
DeleteReport method
"""

def add_report(self, report, index):
    if(index == 1):
        report = 

